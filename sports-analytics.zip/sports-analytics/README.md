# Sports Analytics – Match Outcome Prediction

## 📌 Objective
Predict match outcomes using Machine Learning.

## ⚙️ Algorithms Used
- Logistic Regression
- Decision Tree

## 📊 Dataset
Custom dataset with features:
- Team strength
- Opponent strength
- Home advantage
- Previous wins

## ▶️ How to Run

1. Install dependencies:
pip install -r requirements.txt

2. Run Logistic Regression:
python src/logistic_model.py

3. Run Decision Tree:
python src/decision_tree_model.py

## 📈 Output
Displays prediction accuracy of both models.

## 🔗 GitHub Link
(Add your repo link here)